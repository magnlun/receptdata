//This Java program created by Magnus Lundberg is licensed under a Creative Commons Attribution 3.0 Unported License.
//http://creativecommons.org/licenses/by/3.0/

import java.sql.*;
import java.util.Scanner;
public class Huvud{
	public static void main(String[] args) throws SQLException{
		
		String username = "postgres";
		String password = "4j484j4";
		Scanner sc = new Scanner(System.in);
		while(true){
		System.out.println("Vad vill du göra: \n1. Sätta in ett nytt recept\n2. Hämta ett redan existerande recept\n3. Lägga till en ny ingrediens\n4. Stänga av programmet");
		String menyval = sc.nextLine();
		System.out.println(menyval);
		if(menyval.equals("2")){
			System.out.println("Vilket recept vill du hämta?");
			String recept = sc.nextLine();
			if(recept.endsWith("*") || recept.startsWith("*")){
				String query = "SELECT \"BakNamn\" FROM \"Bakverk\" WHERE \"BakNamn\" LIKE '"+recept.replace('*', '%')+"';";
				String[][] rc = Hämta.hämtning(query, username, password);
				if(rc.length == 2)
					recept = rc[1][0];
				if(rc.length > 2){
					System.out.println("Vilken av:");
					for(int i = 1; i < rc.length; i++){
						System.out.println(i+": " + rc[i][0]);
					}
					recept = rc[sc.nextInt()][0];
					System.out.println(recept);
				}
					
			}
			String query = "SELECT  \"Innehall\".\"Ingrediens\", \"Innehall\".\"Volym\", \"Alternativ\".\"AltIngrediens\", \"Alternativ\".\"Volym\",  \"Instruktioner\" FROM \"Innehall\" NATURAL JOIN \"Bakverk\" LEFT JOIN \"Alternativ\" ON \"Innehall\".\"Ingrediens\" = \"Alternativ\".\"Ingrediens\" AND \"Innehall\".\"BakNamn\" = \"Alternativ\".\"Recept\" WHERE \"Innehall\".\"BakNamn\" = '" + recept + "';";
			String[][] rc = Hämta.hämtning(query, username, password);
			if(rc.length < 2){
				System.out.println("Tyvärr hittade jag inte det där");
			}
			else{
				System.out.print("/");
				for(int i = 0; i < 43; i++)
					if(i == 20)
						System.out.print("-");
					else
						System.out.print("-");
				System.out.println("\\");
					for (int j = 0; j < rc.length; j++) {
						System.out.print("|");
						for (int k = 0; k < 2; k++) {
							System.out.print(rc[j][k].replace("  ", ""));
							if (k == 0) {
								for (int m = 0; m < 20 - rc[j][k].replace("  ","").length(); m++)
									System.out.print(" ");
								System.out.print("|            ");
							}
						}

						for (int n = 0; n < 10 - rc[j][1].replace("  ", "").length(); n++)
							System.out.print(" ");
						System.out.println("|");

						if (rc[j][2] != null && j > 1) {
							System.out.println("|eller:              |                      |");
							System.out.print("|" + rc[j][2].replace("  ", ""));
							for (int m = 0; m < 20 - rc[j][2].replace("  ", "").length(); m++)
								System.out.print(" ");
							System.out.print("|            ");
							System.out.print(rc[j][3].replace("  ", ""));
							for (int m = 0; m < 10 - rc[j][3].replace("  ", "").length(); m++)
								System.out.print(" ");
							System.out.println("|");
						}
					}
				System.out.print("\\");
				for(int i = 0; i < 43; i++)
					if(i == 20)
						System.out.print("-");
					else
						System.out.print("-");
				System.out.println("/");
				System.out.println(rc[1][4]);
			}
		}
		else if(menyval.equals("1")) 
			Sattin.SattIn(username, password);
		else if(menyval.equals("3")){ 
			System.out.println("Vad heter ingrediensen, Är den viktig, hur mycket har du hemma, Hur mycket vill du ha hemma och hur stort är det framtida behovet?");
			String in = sc.nextLine();
			String[] info = in.split(" ");
			if(info[1].equalsIgnoreCase("ja"))
				info[1] = "TRUE";
			else if(info[1].equalsIgnoreCase("nej"))
				info[1] = "FALSE";
			String query = "INSERT INTO \"Ingredienser\"(\"Ingrediens\", \"Viktig\", \"Hemma\", \"Önskad mängd\", \"Framtida behov\") VALUES ('" + info[0] +"','"+ info[1] +"','"+ info[2] +"','"+ info[3] +"','"+ info[4] +"');";
			System.out.println(query);
			//Sattin.kommunikation(query,username, password, "");
		}
		
		else if(menyval.equals("4"))
			break;
	}
	}
}
