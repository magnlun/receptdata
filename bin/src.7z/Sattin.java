//This Java program created by Magnus Lundberg is licensed under a Creative Commons Attribution 3.0 Unported License.
//http://creativecommons.org/licenses/by/3.0/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class Sattin {
	public static void SattIn(String username, String password) throws SQLException{
		String query;
		String ingrediens;
		Scanner sc = new Scanner(System.in);
		String namn = "";
		while(true){
			System.out.println("Vad heter det du vill s�tta in?");
			namn = sc.nextLine();
			if(namn.length() > 0)
				break;
			else
				System.out.println("Mata in ett namn d�");
		}
		System.out.println("Till vilken kategori h�r det?");
		String kategori = sc.nextLine();
		int betyg = 0;
		while(true){
			System.out.println("Vilket betyg vill du ge den?");
			try{
				betyg = Integer.parseInt(sc.nextLine());
				break;
			}
			catch(NumberFormatException err){
				System.out.println("Jag skulle föredra ett tal...");
			}
		}
			
		System.out.println("Lägg in en beskrivning av maträtten, avsluta genom att skriva \"exit\"");
		String beskrivning = "";
		while(true){
			String tmp = sc.nextLine();
			if(tmp.equals("exit"))
				break;
			beskrivning += tmp + "\n";
		}
		int portioner;
		while(true){
			System.out.println("Hur många portioner ligger receptet på?");
			try{
				portioner = Integer.parseInt(sc.nextLine());
				break;
			}
			catch(NumberFormatException err){
				System.out.println("Jag skulle föredra ett tal...");
			}
		}
		query = "INSERT INTO \"Bakverk\"(\"Kategori\", \"BakNamn\", \"Betyg\", \"Instruktioner\", \"Portioner\")  VALUES ('" + kategori + "','" + namn + "','" + betyg + "','" + beskrivning + "','" + portioner + "');";
		kommunikation(query, username, password, "");
		System.out.println("Mata in alla ingredienser på formeln Ingrediens volymsiffra prefix. Avsluta med en tom rad");
		while(true){
			ingrediens = sc.nextLine();
			if(ingrediens.equals(""))
				break;
			String[] volym = ingrediens.split(" ");
			String hopslag = volym[1]+ " " + volym[2];
			query = "INSERT INTO \"Innehall\"(\"BakNamn\", \"Ingrediens\", \"Volym\") VALUES ('"+ namn +"','"+ volym[0] +"','"+ hopslag +"');";
			kommunikation(query, username, password, volym[0]);
		}
		return;

	}
	public static void kommunikation(String query, String username, String password, String ingrediens) throws SQLException{
		Scanner sc = new Scanner(System.in);
		Connection conn = null;
		String connstr = "jdbc:postgresql://127.0.0.1:5432/Recept";
		try {
			Class.forName("org.postgresql.Driver");
		}
		catch (ClassNotFoundException cnfe) {
			System.err.println("Hittar ingen JDBC-driver!");
		}
		try {
			conn = DriverManager.getConnection(connstr, username, password);
		}
		catch (SQLException e) {
			System.out.println("FEL: kunde inte ansluta till databasen!");
		}
		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.executeUpdate();
		}
		catch (SQLException sqle) {
			if(!ingrediens.equals("")){
				String[][] Alias = Hämta.hämtning("SELECT \"Ingrediens\" FROM \"Alias\" WHERE \"Alias\" = '" + ingrediens +"';", username, password);
				if(Alias.length > 1){
					query.replace(ingrediens, Alias[1][0].replace(" ",""));
					System.out.println(query);
					kommunikation(query, username, password, Alias[1][0]);
				}
				else{
					System.out.println("Ingrediensen fanns inte, vill du lägga till den? j/n");
					if(sc.nextLine().equals("j")){
						kommunikation("INSERT INTO \"Ingredienser\"(\"Ingrediens\", \"Viktig\", \"Hemma\", \"�nskad m�ngd\", \"Framtida behov\") VALUES ('" + ingrediens +"','"+ "FALSE" +"','"+ 0 +"','"+ 0 +"','"+ 0 +"');", username, password, "");
						kommunikation(query, username, password, ingrediens);
						System.out.println("Ok, den är tillagd, forts�tt mata in resten av ingredienserna");
					}
					else
						System.out.println("Ok forts�tt inmatningen då");
				}
			}
			else{
				System.err.print("Databasen har stött på ett oväntat fel vid insättningen och kommer därför att stängas");
				try{
					conn.close();
				}
				catch(SQLException tmp){
					
				}
				finally{
					System.exit(1);
				}
			}
			
		}
		conn.close();
		return;
	}
}
