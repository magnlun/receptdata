//This Java program created by Magnus Lundberg is licensed under a Creative Commons Attribution 3.0 Unported License.
//http://creativecommons.org/licenses/by/3.0/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayDeque;


public class Hämta{
	public static String[][] hämtning(String query, String username, String password) throws SQLException{
		Connection conn = null;
		String connstr = "jdbc:postgresql://127.0.0.1:5432/Recept";
		try {
			Class.forName("org.postgresql.Driver");
		}
		catch (ClassNotFoundException cnfe) {
			System.err.println("Hittar ingen JDBC-driver!");
		}
		try {
			conn = DriverManager.getConnection(connstr, username, password);
		}
		catch (SQLException e) {
			System.out.println("FEL: kunde inte ansluta till databasen!");
		}
		ResultSet rs = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
		}
		catch (SQLException sqle) {
			System.out.println("FEL: Kunde inte h�mta data fr�n tabellen!");
		}
			ResultSetMetaData rsmd = rs.getMetaData();
	
			int numColumns = rsmd.getColumnCount();
	
	
	
			final ArrayDeque<String[]> rows = new ArrayDeque<String[]>();
			String[] row = new String[numColumns];
			for (int i = 1; i <= numColumns; i++)
				row[i - 1] = (rsmd.getColumnName(i));
			rows.offer(row);
	
			while (rs.next())
			{
				row = new String[numColumns];
				for (int i = 1; i <= numColumns; i++)
					row[i - 1] = rs.getString(i);
				rows.offer(row);
			}
	
			final String[][] rc = new String[rows.size()][];
			int i = 0;
			while ((row = rows.poll()) != null)
				rc[i++] = row;
			conn.close();
			return rc;
	}
}
